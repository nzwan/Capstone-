

"""
Initializes class Food.
"""
class Food:
    def __init__(self, entree, price1, side, price2, drink, price3,):
        self.entree = entree
        self.price1 = price1
        self.side = side
        self.price2 = price2
        self.drink = drink
        self.price3 = price3
"""
Populates class Food with various items and prices based off generic
categories.
"""
breakfast = Food("Eggs", 5.00, "Bacon", 5.00, "Coffee", 2.99)
lunch = Food("BLT", 5.00, "Chips", 5.00, "Soda", 2.99)
dinner = Food("Steak", 1.00, "Potatoe", 1.00, "Tea", 1.00)

"""
Initializes class Product.
"""
class Product:
    def __init__(self, item, price):
        self.item = item
        self.price = price
"""
Populates class Food with various items and prices based off generic
categories.
"""
electronics = Product("Various", 6.99)
supplies = Product("House Goods", 10.00)
petSupplies = Product("12Lb bag food", 20.00)

"""
Initializes class DeliveryFee
"""

class DeliveryFee:
    def __init__(self, code, price):
        self.code = code
        self.price = price
"""
Populates class DeliveryFee with various items and prices based off generic
categories.
"""
oneToTen = DeliveryFee("01", 4.99)
elevenToTwenty = DeliveryFee("02", 10.00) 
""""
DeliveryFee will reflect that company only delivers as far as 20 Miles
"""
       

def customer():
    name = input("What is the customers Name? ")
    address = input("What is the customers Address?")
    phone = input("What is the customers contact number?")

    
    print("")
    print("")
    print("Customer invoice")
    print("Customer name: ", name)
    print("Customer Address:", address)
    print("Customer Contact number:", phone)



    
"""
Imports Food class and corresponding objects.
"""
from classes import Food
from classes import breakfast
from classes import lunch
from classes import dinner
"""
Imports Product class and corresponding objects.
"""
from classes import Product
from classes import electronics
from classes import supplies
from classes import petSupplies
"""
Imports DellveryFee class and corresponding objects.
"""
from classes import DeliveryFee
from classes import oneToTen
from classes import elevenToTwenty


"""
Creates variable for fee amounts for calclation.
"""
conFee = .05
food_Service_Fee = .20
tax = 0.07
"""
Creates variables to generate generic food packages
"""
food_package1 = (breakfast.price1 + breakfast.price2 + breakfast.price3)
subtotal1 = (food_package1 * conFee) + (food_package1 * food_Service_Fee) + (food_package1 * tax) + (food_package1)
food_package2 = (lunch.price1 + lunch.price2 + lunch.price3)
subtotal2 = (food_package2 * conFee) + (food_package2 * food_Service_Fee) + (food_package2 * tax) + (food_package2)
food_package3 = (dinner.price1 + dinner.price2 + dinner.price3)
subtotal3 = (food_package3 * conFee) + (food_package3 * food_Service_Fee) + (food_package3 * tax) + (food_package3)
"""
Generates final total
"""
total1 = (subtotal1 + oneToTen.price)
total2 = (subtotal2 + oneToTen.price)
total3 = (subtotal3 + oneToTen.price)

total4 = (subtotal1 + elevenToTwenty.price)
total5 = (subtotal1 + elevenToTwenty.price)
total6 = (subtotal3 + elevenToTwenty.price)
"""
Creates variables to generate generic supplies packages
"""
#supply_package1 = (electronics.price)
#supply_package2 = (supplies.price)
#supply_package3 = (petSupplies.price) 
#supply_package4 = (electronics.price + supplies.price + petSupplies.price)
"""
Creates variables to generate generic combo packages
"""
#combo_package1 = (food_package1 + supply_package1)
#combo_package2 = (food_package1 + supply_package2)
#combo_package3 = (food_package3 + supply_package3)
#combo_package4 = (food_package1 + food_package2 + food_package3)
#combo_package5 = (supply_package1 + supply_package2 + supply_package3 + supply_package4)

"""
Runs main program based of UI. Will offer to rerun program
if input is invalid.
"""
def main():
    inquiry = input("Ready to generate customer order? Yes to continue... ")
    if inquiry == "Yes":
        packageInquiry = input("Which package was ordered? breakfast, lunch or dinner?")
    else:
        tryagain = input("Invalid input. try again? Yes or No")
        if tryagain == "Yes":
            main()
        elif tryagain == "No":
            print("Good-bye")
        else:
            print("Good-bye")
    if packageInquiry == "Breakfast":
        print("The Total is $", total1)
    elif packageInquiry == "lunch":
        print("The Total is $", total2)
    elif packageInquiry == "dinner":
        print("The Total is $", total3)
    """
    Used for supply class and orders to be added later.
    """
    #elif inquiry == "supplies" or "Supplies":
        #supplyInquiry = input("Which supply package was ordered? electronics, supplies, or pet supplies ") 
    #elif inquiry == "both" or "Both":
        #comboInquiry = input("Which combo package was ordered? select combo1-combo5? ")
    """
    Sets a standard amount for all orders and will refuse any below $10.00. Tests on Dinner Class. 
    """
    
    if subtotal1 < 10.00:
        print("Does not meet the minimum order requirements. Order must be at least $10.00. Order will not be processed.")

    else:
        rerun = input("Process another order?")
        if rerun == "Yes":
            main()
        elif rerun == "No":
              """
              Calls customer function to print data stored in memory
              """
              customer()
              """
              For testing. Additional totals can be added.
              """
              """
              Prints generic Invoice data
              """
              print("The total is", "$", total1)

        else:
            print("Please choose a valid entry")
            rerun()
            
            
main()







    
    





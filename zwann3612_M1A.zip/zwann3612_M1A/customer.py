def customer():
    name = input("What is the customers Name? ")
    address = input("What is the customers Address? ")
    phone = input("What is the customers contact number? ")


customer()
    
